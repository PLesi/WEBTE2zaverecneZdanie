package com.example.webte2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Webte2Application {

	public static void main(String[] args) {
		SpringApplication.run(Webte2Application.class, args);
	}

}
