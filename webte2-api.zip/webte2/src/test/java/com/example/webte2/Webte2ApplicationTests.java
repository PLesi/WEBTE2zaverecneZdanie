package com.example.webte2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Webte2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
